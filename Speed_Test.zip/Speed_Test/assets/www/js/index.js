(function () {

    // Define online application page
    var appUrl = 'https://fast.com',
        // when application was last restarted
        lastRestart,
        HOUR_MS = 60 * 60 * 1000;

    function forEach(iterable, callback) {
        var array = Array.prototype.slice.call(iterable || []);
        return array.forEach(callback);
    }

    function getElementsByTagName(doc, tagName) {
        return doc.getElementsByTagName(tagName);
    }

    function importsNodes(srDoc, destDoc, tagName, attrLocation, documentLocation) {
        var srcNodes = getElementsByTagName(srDoc, tagName),
            newNodes = [];

        forEach(srcNodes, function (node) {
            var newNode,
                value = node.getAttribute(attrLocation);

            // change relative paths to absolute paths using given document location
            if (
                value &&
                    value.indexOf('http://') !== 0 &&
                        value.indexOf('https://') !== 0 &&
                            value.indexOf(documentLocation) !== 0
            ) {
                node.setAttribute(attrLocation, documentLocation + '/' + value);
            }

            // Script tag cannot be imported on last iOS WebKit
            if (tagName === 'script') {
                newNode = destDoc.createElement(tagName);
                newNode.setAttribute('type', 'text/javascript');
                newNode.setAttribute(attrLocation, node.getAttribute(attrLocation));
            } else {
                newNode = destDoc.importNode(node, true);
            }

            newNodes.push(newNode);

            node.parentNode.removeChild(node);
        });

        return newNodes;
    }

    function replaceLinks(doc, tagName, attrLocation, documentLocation) {
        var nodes = getElementsByTagName(doc, tagName);

        forEach(nodes, function (node) {
            var newNode,
                value = node.getAttribute(attrLocation);

            // change relative paths to absolute paths using given document location
            if (
                value &&
                    value.indexOf('http://') !== 0 &&
                        value.indexOf('https://') !== 0 &&
                            value.indexOf(documentLocation) !== 0
            ) {
                node.setAttribute(attrLocation, documentLocation + '/' + value);
            }
        });
    }

    function injectNodes(nodes, destDoc, target) {
        var destBody = getElementsByTagName(destDoc, target)[0];
        forEach(nodes, function (node) {
            destBody.appendChild(node);
        });
    }

    function removeNodes(nodes) {
        forEach(nodes, function (node) {
            if (node.parentNode) {
                node.parentNode.removeChild(node);
            }
        });
    }

    function importBody(srcDoc, destDoc) {
        var srcBody = getElementsByTagName(srcDoc, 'body')[0],
            destBody = getElementsByTagName(destDoc, 'body')[0];

        // Avoid appendChild on body, here we removed scripts tags
        // and will execute them after via injectNodes
        destBody.innerHTML = srcBody.innerHTML;
    }

    function parseFromStringShim(markup, type) {
        var
          doc = document.implementation.createHTMLDocument("");
            if (markup.toLowerCase().indexOf('<!doctype') > -1) {
                doc.documentElement.innerHTML = markup;
            }
            else {
                doc.body.innerHTML = markup;
            }
        return doc;
    }

    var appLocationTimer, appLocationScripts, newLocationStylesheets;
    function loadPageAsync(url, language) {

        clearTimeout(appLocationTimer);
        appLocationTimer = setTimeout(function () {

            removeNodes(appLocationScripts);
            removeNodes(newLocationStylesheets);

            var oReq = new XMLHttpRequest();

            oReq.onreadystatechange = function (aEvt) {
                if (oReq.readyState == 4) {
                    if (oReq.status == 200) {
                        var parser = new DOMParser(),
                            originalDoc = document,
                            newDocument = parser.parseFromString(this.responseText, "text/html"),
                            newScripts,
                            newStylesheets;

                        if (!newDocument) {
                            newDocument = parseFromStringShim(this.responseText, "text/html");
                        }
                        newScripts = importsNodes(newDocument, originalDoc, 'script', 'src', url),
                        newStylesheets = importsNodes(newDocument, originalDoc, 'link', 'href', url);

                        // Brutal import
                        injectNodes(newStylesheets, originalDoc, 'head');
                        importBody(newDocument, originalDoc);

                        // Execute JS
                        injectNodes(newScripts, originalDoc, 'body');

                        appLocationScripts = newScripts;
                        newLocationStylesheets = newStylesheets;

                        // replace links to FAQ documents
                        replaceLinks(originalDoc, 'span', 'target-language-path', url);
                    } else {
                        showMessage('Failed to load fast.com speed test. Please check that your device is online and try again.')
                    }
                    // Page should be ready, hide splashscreen
                    if (navigator && navigator.splashscreen) {
                        setTimeout(function() {
                            navigator.splashscreen.hide();
                        }, 250);
                    }
                }
            };

            oReq.open("GET", url);
            oReq.setRequestHeader("accept-language", language);
            oReq.send();
        });
    }

    window.loadPageAsync = loadPageAsync;

    function handleOpenURL(url) {

        var indentUrl,
            scheme = 'myspeed',
            schemeProtocol = scheme + ':/';

        if (url && url.indexOf(schemeProtocol) === 0) {
            indentUrl = url.replace(schemeProtocol, '');
            loadPageAsync(indentUrl);
        }
    }

    // Expose to window (required by scheme handler)
    window.handleOpenURL = loadPageAsync;

    function isConnected() {
        var networkState = navigator.connection ? navigator.connection.type : 'unknown';
        return (networkState !== "none");
    }

    function showMessage(message) {
        document.body.innerHTML = '<section id="message" class="center">' +
                                '<p>' + message + '</p>' +
                                '<button id="retry" type="button" class="btn">Retry</button>' +
                                '</section>';
        document.getElementById("retry").addEventListener("click", app.onDeviceReady, false);
        // set last restart to None, so fast.com page is fetched on next retry
        lastRestart = null;
    }

    var app = {

        initialize: function() {
            this.bindEvents();

            if (location.hostname === 'localhost') {
                this.onDeviceReady();
            }
        },

        initLogInfo: function() {
            navigator.deviceData = {
                connection: navigator.connection ? navigator.connection.type : 'unknown',
                device: {
                    platform: navigator.platform,
                    vendor: navigator.vendor,
                    device: device
                },
                language: navigator.language,
                appVersion: '1.0.0'
            }
        },

        bindEvents: function() {
            document.addEventListener('deviceready', this.onDeviceReady, false);
            document.addEventListener('resume', this.onDeviceReady, false);
        },

        onDeviceReady: function() {
            var now = new Date().getTime();

            if(window.MobileAccessibility && window.device && device.platform.toLowerCase() === 'android'){
                window.MobileAccessibility.usePreferredTextZoom(false);
            }
            app.initLogInfo();
            if (isConnected() || lastRestart) {
                // fetch new app if we last ran test 1 hour ago or earlier
                // we want to re-fetch the app so we can pull new updates
                // at the same time, re-fetching on every app resume might be annoying to users
                if (!lastRestart || (now - lastRestart > HOUR_MS)) {
                    lastRestart = now;
                    if (navigator && navigator.splashscreen) {
                        navigator.splashscreen.show();
                    }
                    document.removeEventListener("online",  app.onDeviceReady);
                    navigator.globalization.getPreferredLanguage(
                        function (language) {
                            loadPageAsync(appUrl, language.value);
                        },
                        function () {
                            loadPageAsync(appUrl, 'en-US');
                        }
                    );
                }
            } else {
                if (navigator && navigator.splashscreen) {
                   navigator.splashscreen.hide();
                }
                showMessage('Your device is offline. FAST speed test requires internet connection to start.')
                document.addEventListener("online",  app.onDeviceReady, false);
            }
        }
    };

    app.initialize();

} ());
